
# เฮียชา จัดให้ - ระบบสมัครสมาชิกด้วย Google Apps Script

## วิธีใช้งาน:
1. สร้าง Google Sheet แล้วเปลี่ยนชื่อชีทเป็น: สมาชิกเฮียชา
2. ไปที่ Extensions > Apps Script แล้ววางโค้ดใน Code.gs
3. Deploy เป็น Web App (ตั้งให้ Anyone สามารถเข้าถึง)
4. แทนที่ 'YOUR_SCRIPT_URL_HERE' ใน script.js ด้วย URL จาก Web App
5. อัปโหลดไฟล์ทั้งหมดไว้ในโฮสของคุณ แล้วใช้งานได้เลย!

โลโก้อยู่ในไฟล์ logo.png (ใส่ในหน้าเว็บแล้ว)
